package com.test.response;

import java.io.Serializable;
import java.util.List;

import com.test.request.Student;

public class ResponseObject implements Serializable {
	/**Default SVID  */
	private static final long serialVersionUID = 1L;
	
	private List<Student> students;

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
}
