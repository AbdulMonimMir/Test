package com.test.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.test.request.RequestObject;
import com.test.request.Student;
import com.test.response.ResponseObject;

@Controller
@ComponentScan
@EnableAutoConfiguration
public class TestController {
	
	@RequestMapping("/rest/parseList")
    @ResponseBody
    ResponseObject parseList(@RequestParam("startRollNo") int startRollNo,@RequestParam("endRollNo") int endRollNo, @RequestBody RequestObject request) {
		List<Student> students=new ArrayList<>();
		
		if(null!=request.getStudents() && request.getStudents().size()>0 ) {
			
			for(Student std: request.getStudents() ){
				if(std.getRoll()>=startRollNo && std.getRoll() <=endRollNo ){
					students.add(std);
				}
			}
		}
		
		ResponseObject response=new ResponseObject();
		response.setStudents(students);
		
        return response;
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(TestController.class, args);
    }
}
