package com.test.request;

import java.io.Serializable;
import java.util.List;

public class RequestObject implements Serializable{

	/**Default SVID  */
	private static final long serialVersionUID = 1L;
	
	private List<Student> students;

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
}
