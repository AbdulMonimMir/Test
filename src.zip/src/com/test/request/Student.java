package com.test.request;

import java.io.Serializable;

public class Student implements Serializable {

	/**Default SVID */
	private static final long serialVersionUID = 1L;
	private int roll;
	private String name;
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
